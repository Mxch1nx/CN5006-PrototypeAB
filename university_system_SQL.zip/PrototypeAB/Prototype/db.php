<?php
$conn = new mysqli("localhost", "root", "", "university_system");
if ($conn->connect_error) die("DB Connection failed");
$conn->set_charset("utf8mb4");
