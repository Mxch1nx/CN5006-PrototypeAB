<?php
session_start();
require_once "auth.php";
requireTeacher();



if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}


if ($_SESSION["role"] !== "teacher") {
    echo "Δεν έχετε πρόσβαση σε αυτή τη σελίδα.";
    exit;
}

$username = $_SESSION["username"];
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="css/teacher_home.css">
</head>

<body>

<div class="header">Student Dashboard</div>

<div class="box">
    <h2>Καλωσόρισες, <?= htmlspecialchars($username) ?>!</h2>
    <p>Είσαι συνδεδεμένος ως <strong>Φοιτητής</strong>.</p>

    <a class="logout" href="logout.php">Αποσύνδεση</a>
</div>

</body>
</html>
