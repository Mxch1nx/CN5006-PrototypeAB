<?php
require_once "auth.php";
requireStudent();

require_once "db.php";

$username = $_SESSION["username"] ?? "Student";


$sql = "
    SELECT c.id, c.title, c.description, u.username AS teacher_name
    FROM courses c
    JOIN users u ON c.teacher_id = u.id
    ORDER BY c.id DESC
";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Courses</title>
  <link rel="stylesheet" href="css/student_home.css">
  <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>

<div class="header">Student Dashboard</div>

<div class="box">
  <h2>Μαθήματα</h2>

  <?php if ($result && $result->num_rows > 0): ?>
    <table style="width:100%; border-collapse:collapse;">
      <thead>
        <tr>
          <th style="text-align:left; padding:10px; border-bottom:1px solid #2a2a2a;">ID</th>
          <th style="text-align:left; padding:10px; border-bottom:1px solid #2a2a2a;">Τίτλος</th>
          <th style="text-align:left; padding:10px; border-bottom:1px solid #2a2a2a;">Περιγραφή</th>
          <th style="text-align:left; padding:10px; border-bottom:1px solid #2a2a2a;">Καθηγητής</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <td style="padding:10px; border-bottom:1px solid #1f1f1f;"><?php echo (int)$row["id"]; ?></td>
            <td style="padding:10px; border-bottom:1px solid #1f1f1f;"><?php echo htmlspecialchars($row["title"]); ?></td>
            <td style="padding:10px; border-bottom:1px solid #1f1f1f;"><?php echo htmlspecialchars($row["description"]); ?></td>
            <td style="padding:10px; border-bottom:1px solid #1f1f1f;"><?php echo htmlspecialchars($row["teacher_name"]); ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p>Δεν υπάρχουν διαθέσιμα μαθήματα.</p>
  <?php endif; ?>

  <p style="margin-top:18px;">
    <a href="dashboard.php">⬅ Πίσω στο Dashboard</a>
  </p>
</div>

</body>
</html>
<?php $conn->close(); ?>
