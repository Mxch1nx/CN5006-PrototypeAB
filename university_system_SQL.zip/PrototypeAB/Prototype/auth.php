<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function requireLogin() {
    if (!isset($_SESSION["user_id"])) {
        header("Location: login.php");
        exit();
    }

    $role = $_SESSION["role"] ?? "";
    if ($role !== "student" && $role !== "teacher") {
        session_unset();
        session_destroy();
        header("Location: login.php");
        exit();
    }
}

function requireTeacher() {
    requireLogin();
    if (($_SESSION["role"] ?? "") !== "teacher") {
        header("Location: dashboard.php");
        exit();
    }
}

function requireStudent() {
    requireLogin();
    if (($_SESSION["role"] ?? "") !== "student") {
        header("Location: dashboard.php");
        exit();
    }
}
