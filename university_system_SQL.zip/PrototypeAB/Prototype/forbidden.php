<?php
http_response_code(403);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forbidden</title>
   


</head>
<body>

<div class="box">
    <h1>Forbidden Action</h1>
    <p>You do not have permission to access this page.</p>
    <a href="dashboard.php">Back to Dashboard</a>
</div>

</body>
</html>
