<?php
require_once "auth.php";
requireLogin();

$username = $_SESSION["username"] ?? "User";
$role = $_SESSION["role"] ?? "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>

 
  <link rel="stylesheet" href="css/student_home.css">
  <link rel="stylesheet" href="css/teacher_home.css">

  <link rel="stylesheet" href="css/dashboard.css">
</head>

<body class="<?php echo ($role === 'teacher') ? 'role-teacher' : 'role-student'; ?>">

  
  <div class="header">Dashboard</div>

  <div class="box">
    <h2>Welcome, <?php echo htmlspecialchars($username); ?>!</h2>

    <?php if ($role === "student"): ?>

      <div class="menu">
        <a class="menuItem" href="student_courses.php">View Courses</a>
        <a class="menuItem" href="student_assignments.php">View Assignments</a>
        <a class="menuItem" href="student_submit.php">Submit Assignment</a>
        <a class="menuItem" href="student_grades.php">View Grades</a>
      </div>

    <?php elseif ($role === "teacher"): ?>

      <div class="menu">
        <a class="menuItem" href="teacher_courses.php">Manage Courses</a>
        <a class="menuItem" href="teacher_assignments.php">Post Assignments</a>
        <a class="menuItem" href="teacher_submissions.php">View Submissions</a>
        <a class="menuItem" href="teacher_submissions.php">Grade Students</a>
      </div>

    <?php else: ?>
      <?php
        http_response_code(403);
        echo "<h2>Forbidden Action</h2>";
        exit;
      ?>
    <?php endif; ?>

    <a class="logout" href="logout.php">Logout</a>
  </div>

</body>
</html>
