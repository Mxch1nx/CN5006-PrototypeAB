<?php
require_once "auth.php";
requireStudent();

require_once "db.php";


$sql = "
  SELECT 
    id,
    course_id,
    title,
    description,
    due_date,
    created_at
  FROM assignments
  ORDER BY created_at DESC
";

$result = $conn->query($sql);
if (!$result) {
  die("SQL Error: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <title>Student Assignments</title>
  <link rel="stylesheet" href="css/student_home.css">
</head>
<body>

<div class="header">Student Dashboard</div>

<div class="box">
  <h2>Εργασίες</h2>

  <?php if ($result->num_rows === 0): ?>
    <p>Δεν υπάρχουν εργασίες ακόμα.</p>
  <?php else: ?>
    <div class="menu" style="gap:10px;">
      <?php while($row = $result->fetch_assoc()): ?>
        <div class="menuItem" style="display:block; text-align:left;">
          <strong><?php echo htmlspecialchars($row["title"]); ?></strong><br>
          <span><?php echo htmlspecialchars($row["description"]); ?></span><br><br>

          <small>
            Course ID: <?php echo (int)$row["course_id"]; ?> |
            Due: <?php echo htmlspecialchars($row["due_date"]); ?>
          </small>
        </div>
      <?php endwhile; ?>
    </div>
  <?php endif; ?>

  <br>
  <a class="logout" href="dashboard.php">⬅ Πίσω</a>
</div>

</body>
</html>
