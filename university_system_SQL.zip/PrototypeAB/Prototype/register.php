<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {

   
    $conn = new mysqli("localhost", "root", "", "university_system");

    
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }
    
    $username = trim($_POST["username"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"]; 
    $role = $_POST["role"];
    $special_code = trim($_POST["special_code"]);

    
    $student_code = "STUD2025";
    $teacher_code = "PROF2025";

   
    if (($role === "student" && $special_code !== $student_code) ||
        ($role === "teacher" && $special_code !== $teacher_code)) {

       
        $error = "Λάθος ειδικός κωδικός για τον ρόλο που επιλέξατε.";
    } 
    else {

        
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        
        $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)");

        
        $stmt->bind_param("ssss", $username, $email, $password_hash, $role);

       
        if ($stmt->execute()) {
        
            $success = "Η εγγραφή ολοκληρώθηκε! Μπορείτε πλέον να συνδεθείτε.";
        } else {
          
            $error = "Σφάλμα: Το email υπάρχει ήδη ή κάτι πήγε λάθος.";
        }
   
        $stmt->close();
    }
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="el">
<head>
    <link rel="stylesheet" href="css/register.css">
    <meta charset="UTF-8">
    <title>Εγγραφή Χρήστη</title>
</head>

<body>


<div class="box">
    <h2>Εγγραφή Χρήστη</h2>

    <?php if(isset($error)): ?>
        <div class="msg error"><?= $error ?></div>
    <?php endif; ?>

    <?php if(isset($success)): ?>
        <div class="msg success"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST">

        <label>Username</label>
        <input type="text" name="username" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <label>Ρόλος</label>
        <select name="role" required>
            <option value="student">Φοιτητής</option>
            <option value="teacher">Καθηγητής</option>
        </select>

        <label>Ειδικός Κωδικός</label>
        <input type="text" name="special_code" required>

        <button type="submit">Εγγραφή</button>

    </form>
</div>

</body>
</html>
