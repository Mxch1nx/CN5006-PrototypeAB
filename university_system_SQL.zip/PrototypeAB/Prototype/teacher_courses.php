<?php
require_once "auth.php";
requireTeacher();

require_once "db.php";

$teacherId = $_SESSION["user_id"];
$success = "";
$error = "";


if (isset($_POST["create"])) {
  $title = trim($_POST["title"]);
  $description = trim($_POST["description"]);

  if ($title == "") {
    $error = "Βάλε τίτλο.";
  } else {
    $stmt = $conn->prepare("INSERT INTO courses (title, description, teacher_id, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("ssi", $title, $description, $teacherId);
    if ($stmt->execute()) $success = "OK - δημιουργήθηκε.";
    else $error = "Σφάλμα δημιουργίας.";
    $stmt->close();
  }
}


if (isset($_POST["delete"])) {
  $courseId = (int)$_POST["course_id"];
  $stmt = $conn->prepare("DELETE FROM courses WHERE id=? AND teacher_id=?");
  $stmt->bind_param("ii", $courseId, $teacherId);
  if ($stmt->execute()) $success = "OK - διαγράφηκε.";
  else $error = "Σφάλμα διαγραφής.";
  $stmt->close();
}


$stmt = $conn->prepare("SELECT id, title, description, created_at FROM courses WHERE teacher_id=? ORDER BY id DESC");
$stmt->bind_param("i", $teacherId);
$stmt->execute();
$res = $stmt->get_result();
$courses = $res->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>

  
  <link rel="stylesheet" href="css/teacher_courses.css">
</head>
<body>

  
  <div class="header">
    <div class="header-left">
      <div class="header-title">Dashboard</div>
      <div class="header-subtitle">Manage Courses</div>
    </div>
    <a class="header-link" href="dashboard.php">Back</a>
  </div>

  <div class="page">
    <div class="card">

      <div class="card-head">
        <h2>Courses</h2>
        <p>Δημιούργησε και διαχειρίσου τα μαθήματά σου.</p>
      </div>

      <?php if ($success): ?>
        <div class="alert success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>

      <?php if ($error): ?>
        <div class="alert error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <div class="grid">
       
        <section class="panel">
          <h3>Create Course</h3>

          <form method="post" class="form">
            <label class="field">
              <span>Title</span>
              <input type="text" name="title" placeholder="Course title">
            </label>

            <label class="field">
              <span>Description</span>
              <textarea name="description" placeholder="Description"></textarea>
            </label>

            <button class="btn primary" type="submit" name="create">Create</button>
          </form>
        </section>

       
        <section class="panel">
          <h3>My Courses</h3>

          <?php if (count($courses) == 0): ?>
            <div class="empty">No courses yet.</div>
          <?php else: ?>
            <div class="table-wrap">
              <table class="table">
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Created</th>
                    <th style="width: 120px;">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($courses as $c): ?>
                    <tr>
                      <td><?= htmlspecialchars($c["title"]) ?></td>
                      <td class="muted"><?= htmlspecialchars($c["description"]) ?></td>
                      <td class="muted"><?= htmlspecialchars($c["created_at"]) ?></td>
                      <td>
                        <form method="post" class="inline">
                          <input type="hidden" name="course_id" value="<?= (int)$c["id"] ?>">
                          <button class="btn danger" type="submit" name="delete">Delete</button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </section>
      </div>

    </div>
  </div>

</body>
</html>
