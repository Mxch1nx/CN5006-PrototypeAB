<?php
require_once "auth.php";
requireTeacher();
require_once "db.php";

$teacherId = $_SESSION["user_id"] ?? 0;

$success = "";
$error = "";


$courses = [];
$stmt = $conn->prepare("SELECT id, title FROM courses WHERE teacher_id=? ORDER BY id DESC");
$stmt->bind_param("i", $teacherId);
$stmt->execute();
$res = $stmt->get_result();
$courses = $res->fetch_all(MYSQLI_ASSOC);
$stmt->close();


if (isset($_POST["post"])) {
  $title = trim($_POST["title"] ?? "");
  $description = trim($_POST["description"] ?? "");
  $course_id = (int)($_POST["course_id"] ?? 0);
  $due_date_raw = trim($_POST["due_date"] ?? ""); 

  if ($title === "" || $description === "" || $course_id <= 0 || $due_date_raw === "") {
    $error = "Συμπλήρωσε όλα τα πεδία.";
  } else {
   
    $due_date = $due_date_raw . " 23:59:59";

    
    $chk = $conn->prepare("SELECT id FROM courses WHERE id=? AND teacher_id=? LIMIT 1");
    $chk->bind_param("ii", $course_id, $teacherId);
    $chk->execute();
    $chkRes = $chk->get_result();
    $courseOk = ($chkRes && $chkRes->num_rows === 1);
    $chk->close();

    if (!$courseOk) {
      $error = "Το μάθημα που διάλεξες δεν ανήκει στον λογαριασμό σου.";
    } else {
     
      $ins = $conn->prepare("
        INSERT INTO assignments (course_id, title, description, due_date, created_at)
        VALUES (?, ?, ?, ?, NOW())
      ");
      $ins->bind_param("isss", $course_id, $title, $description, $due_date);

      if ($ins->execute()) {
        $success = "OK - Η εργασία αναρτήθηκε!";
      } else {
        $error = "Σφάλμα στη βάση: " . $conn->error;
      }
      $ins->close();
    }
  }
}
?>
<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <link rel="stylesheet" href="css/teacher_assignments.css">
</head>
<body>

  <div class="header">
    <div class="header-left">
      <div class="header-title">Dashboard</div>
      <div class="header-subtitle">Post Assignments</div>
    </div>
    <a class="header-link" href="dashboard.php">Back</a>
  </div>

  <div class="page">
    <div class="card">

      <div class="card-head">
        <h2>Ανάρτηση Εργασίας</h2>
        <p>Διάλεξε μάθημα και συμπλήρωσε τα στοιχεία.</p>
      </div>

      <?php if ($success): ?>
        <div class="alert success"><?php echo htmlspecialchars($success); ?></div>
      <?php endif; ?>

      <?php if ($error): ?>
        <div class="alert error"><?php echo htmlspecialchars($error); ?></div>
      <?php endif; ?>

      <section class="panel">
        <form method="post" class="form">

          <label class="field">
            <span>Τίτλος</span>
            <input type="text" name="title" placeholder="π.χ. Εργασία 1" required>
          </label>

          <label class="field">
            <span>Μάθημα</span>
            <select name="course_id" required>
              <option value="">-- Διάλεξε μάθημα --</option>
              <?php foreach ($courses as $c): ?>
                <option value="<?php echo (int)$c["id"]; ?>">
                  <?php echo (int)$c["id"] . " - " . htmlspecialchars($c["title"]); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </label>

          <label class="field field-wide">
            <span>Περιγραφή</span>
            <textarea name="description" placeholder="Οδηγίες / απαιτήσεις..." required></textarea>
          </label>

          <label class="field">
            <span>Due Date</span>
            <input type="date" name="due_date" required>
          </label>

          <button class="btn primary field-wide" type="submit" name="post">Ανάρτηση</button>

        </form>
      </section>

    </div>
  </div>

</body>
</html>
