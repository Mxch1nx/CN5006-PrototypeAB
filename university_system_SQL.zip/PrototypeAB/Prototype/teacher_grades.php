<?php
require_once "auth.php";
requireTeacher();
require_once "db.php";

$teacher_id = $_SESSION["teacher_id"] ?? $_SESSION["user_id"] ?? 0;
$submission_id = isset($_GET["submission_id"]) ? (int)$_GET["submission_id"] : 0;


if ($submission_id <= 0) {
    header("Location: teacher_submissions.php");
    exit();
}


$sql = "
  SELECT 
    s.id,
    s.student_id,
    s.submission_text,
    s.file_path,
    s.submitted_at,
    a.title AS assignment_title,
    a.due_date
  FROM submissions s
  JOIN assignments a ON s.assignment_id = a.id
  WHERE s.id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $submission_id);
$stmt->execute();
$result = $stmt->get_result();
$submission = $result->fetch_assoc();
$stmt->close();

if (!$submission) {
    header("Location: teacher_submissions.php");
    exit();
}


$stmt2 = $conn->prepare("SELECT grade_value, feedback FROM grades WHERE submission_id = ?");
$stmt2->bind_param("i", $submission_id);
$stmt2->execute();
$existing = $stmt2->get_result()->fetch_assoc();
$stmt2->close();

$success = "";
$error = "";


if (isset($_POST["save"])) {
    $grade = trim($_POST["grade_value"]);
    $feedback = trim($_POST["feedback"]);

    if ($grade === "") {
        $error = "Βάλε βαθμό.";
    } else {
        if ($existing) {
            $stmt3 = $conn->prepare("
              UPDATE grades 
              SET teacher_id=?, grade_value=?, feedback=?, graded_at=NOW()
              WHERE submission_id=?
            ");
            $stmt3->bind_param("idsi", $teacher_id, $grade, $feedback, $submission_id);
        } else {
            $stmt3 = $conn->prepare("
              INSERT INTO grades (submission_id, teacher_id, grade_value, feedback, graded_at)
              VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt3->bind_param("iids", $submission_id, $teacher_id, $grade, $feedback);
        }

        if ($stmt3->execute()) {
            $success = "Η βαθμολογία αποθηκεύτηκε!";
            $existing = ["grade_value"=>$grade, "feedback"=>$feedback];
        } else {
            $error = "Σφάλμα αποθήκευσης.";
        }

        $stmt3->close();
    }
}
?>

<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <title>Grade Student</title>
  <link rel="stylesheet" href="css/teacher_home.css">
</head>
<body>

<div class="header">Teacher Dashboard</div>

<div class="box" style="max-width:800px; text-align:left;">
  <h2>Βαθμολόγηση Φοιτητή</h2>

  <?php if ($success): ?>
    <p style="color:lightgreen;"><?php echo $success; ?></p>
  <?php endif; ?>

  <?php if ($error): ?>
    <p style="color:salmon;"><?php echo $error; ?></p>
  <?php endif; ?>

  <p><strong>Εργασία:</strong> <?php echo htmlspecialchars($submission["assignment_title"]); ?></p>
  <p><strong>Student ID:</strong> <?php echo $submission["student_id"]; ?></p>
  <p><strong>Submitted:</strong> <?php echo $submission["submitted_at"]; ?></p>

  <p><strong>Κείμενο:</strong><br>
    <?php echo nl2br(htmlspecialchars($submission["submission_text"])); ?>
  </p>

  <?php if (!empty($submission["file_path"])): ?>
    <p><a href="<?php echo $submission["file_path"]; ?>" target="_blank">Άνοιγμα αρχείου</a></p>
  <?php endif; ?>

  <hr>

  <form method="POST">
    <label>Βαθμός:</label><br>
    <input type="text" name="grade_value" value="<?php echo $existing["grade_value"] ?? ""; ?>" required><br><br>

    <label>Feedback:</label><br>
    <textarea name="feedback" rows="4"><?php echo $existing["feedback"] ?? ""; ?></textarea><br><br>

    <button type="submit" name="save">Αποθήκευση</bu
