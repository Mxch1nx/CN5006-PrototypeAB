<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Συνδεση στη βαση
    $conn = new mysqli("localhost", "root", "", "university_system");

    // Έλεγχος για αποτυχια συνδεσης
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    
    $stmt = $conn->prepare("SELECT id, username, password_hash, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    
    if ($stmt->num_rows === 1) {

        
        $stmt->bind_result($id, $username, $password_hash, $role);
        $stmt->fetch();

        
        if (password_verify($password, $password_hash)) {

           
            unset($_SESSION["teacher_id"], $_SESSION["student_id"]);

            
            $_SESSION["user_id"] = $id;
            $_SESSION["username"] = $username;
            $_SESSION["role"] = $role;

           
            if ($role === "teacher") {
                $_SESSION["teacher_id"] = $id;
            } elseif ($role === "student") {
                $_SESSION["student_id"] = $id;
            }

          
            header("Location: dashboard.php");
            exit;

        } else {
         
            $error = "Λάθος email ή κωδικός.";
        }

    } else {
       
        $error = "Λάθος email ή κωδικός.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <title>Σύνδεση</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>

<div class="box">
    <h2>Σύνδεση Χρήστη</h2>

    <?php if(isset($error)): ?>
        <div class="msg error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <button type="submit">Σύνδεση</button>

    </form>

    <p style="text-align:center; margin-top:10px;">
        Δεν έχετε λογαριασμό; <a href="register.php">Εγγραφή</a>
    </p>
</div>

</body>
</html>
