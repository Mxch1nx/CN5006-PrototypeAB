<?php
require_once "auth.php";
requireStudent();

require_once "db.php";

$student_id = (int)($_SESSION["user_id"] ?? 0);

$assignment_id = isset($_GET["assignment_id"]) ? (int)$_GET["assignment_id"] : 0;
if (isset($_POST["assignment_id"])) {
    $assignment_id = (int)$_POST["assignment_id"];
}

$success = "";
$error = "";


if (isset($_POST["submit"])) {
    $submission_text = trim($_POST["submission_text"] ?? "");
    $file_path = "";

    
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . "/uploads";
        if (!is_dir($uploadDir)) {
            @mkdir($uploadDir, 0777, true);
        }

        $originalName = basename($_FILES["file"]["name"]);
        $safeName = time() . "_" . preg_replace("/[^a-zA-Z0-9._-]/", "_", $originalName);
        $targetFsPath = $uploadDir . "/" . $safeName;

        if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFsPath)) {
            
            $file_path = "uploads/" . $safeName;
        } else {
            $error = "Αποτυχία upload αρχείου.";
        }
    }

    if ($error === "") {
        if ($assignment_id <= 0) {
            $error = "Διάλεξε εργασία.";
        } elseif ($submission_text === "" && $file_path === "") {
            $error = "Γράψε κείμενο ή ανέβασε αρχείο.";
        } else {
            $stmt = $conn->prepare("
                INSERT INTO submissions (assignment_id, student_id, submission_text, file_path, submitted_at)
                VALUES (?, ?, ?, ?, NOW())
            ");
            if (!$stmt) {
                $error = "SQL Error: " . $conn->error;
            } else {
                $stmt->bind_param("iiss", $assignment_id, $student_id, $submission_text, $file_path);
                if ($stmt->execute()) {
                    $success = "Η υποβολή έγινε επιτυχώς!";
                } else {
                    $error = "Δεν έγινε η υποβολή. (" . $stmt->error . ")";
                }
                $stmt->close();
            }
        }
    }
}


$assignments = [];
$resA = $conn->query("SELECT id, title FROM assignments ORDER BY id DESC");
if ($resA) {
    while ($r = $resA->fetch_assoc()) $assignments[] = $r;
}
?>
<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Submit Assignment</title>
  <link rel="stylesheet" href="css/student_home.css">
  <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>

<div class="header">Student Dashboard</div>

<div class="box">
  <h2>Υποβολή Εργασίας</h2>

  <?php if ($success !== ""): ?>
    <div class="msg success"><?php echo htmlspecialchars($success); ?></div>
  <?php endif; ?>
  <?php if ($error !== ""): ?>
    <div class="msg error"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data">

    <label>Εργασία</label>
    <select name="assignment_id" required>
      <option value="">-- Επιλογή --</option>
      <?php foreach ($assignments as $a): ?>
        <option value="<?php echo (int)$a["id"]; ?>" <?php echo ((int)$a["id"] === (int)$assignment_id) ? "selected" : ""; ?>>
          <?php echo htmlspecialchars($a["title"]); ?> (ID: <?php echo (int)$a["id"]; ?>)
        </option>
      <?php endforeach; ?>
    </select>

    <label style="margin-top:10px;">Κείμενο Υποβολής (προαιρετικό)</label>
    <textarea name="submission_text" rows="6" placeholder="Γράψε εδώ..."></textarea>

    <label style="margin-top:10px;">Αρχείο (προαιρετικό)</label>
    <input type="file" name="file">

    <button type="submit" name="submit" style="margin-top:12px;">Υποβολή</button>
  </form>

  <p style="margin-top:18px;">
    <a href="dashboard.php">⬅ Πίσω στο Dashboard</a>
  </p>
</div>

</body>
</html>
<?php $conn->close(); ?>
