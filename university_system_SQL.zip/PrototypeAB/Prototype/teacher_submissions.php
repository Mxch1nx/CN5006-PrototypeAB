<?php
require_once "auth.php";
requireTeacher();

require_once "db.php";

$teacher_id = $_SESSION["teacher_id"] ?? ($_SESSION["user_id"] ?? 0);


$selected_assignment_id = isset($_GET["assignment_id"]) ? (int)$_GET["assignment_id"] : 0;


$assignments = [];
$resA = $conn->query("SELECT id, title, due_date FROM assignments ORDER BY created_at DESC");
if ($resA) {
    while ($row = $resA->fetch_assoc()) {
        $assignments[] = $row;
    }
}


if ($selected_assignment_id === 0 && count($assignments) > 0) {
    $selected_assignment_id = (int)$assignments[0]["id"];
}


$submissions = [];
if ($selected_assignment_id > 0) {
    $sql = "
        SELECT
            s.id AS submission_id,
            s.student_id,
            s.submission_text,
            s.file_path,
            s.submitted_at,
            g.grade_value,
            g.graded_at
        FROM submissions s
        LEFT JOIN grades g ON g.submission_id = s.id
        WHERE s.assignment_id = ?
        ORDER BY s.submitted_at DESC
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $selected_assignment_id);
    $stmt->execute();
    $resS = $stmt->get_result();

    while ($row = $resS->fetch_assoc()) {
        $submissions[] = $row;
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <title>Teacher Submissions</title>
  <link rel="stylesheet" href="css/teacher_submissions.css">
</head>
<body>

<div class="header">Teacher Dashboard</div>

<div class="container">
  <h2 class="pageTitle">Υποβολές Φοιτητών</h2>

  <div class="filterBox">
    <form method="GET" class="filterForm">
      <label class="filterLabel">Επιλογή Εργασίας:</label>

      <select name="assignment_id" class="filterSelect" onchange="this.form.submit()">
        <?php foreach ($assignments as $a): ?>
          <option value="<?php echo (int)$a["id"]; ?>"
            <?php echo ((int)$a["id"] === (int)$selected_assignment_id) ? "selected" : ""; ?>>
            <?php echo htmlspecialchars($a["title"]); ?> (ID: <?php echo (int)$a["id"]; ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </form>

    <a class="backBtn" href="dashboard.php">⬅ Πίσω</a>
  </div>

  <?php if ($selected_assignment_id === 0): ?>
    <div class="emptyState">Δεν υπάρχουν εργασίες.</div>
  <?php else: ?>

    <?php if (count($submissions) === 0): ?>
      <div class="emptyState">Δεν υπάρχουν υποβολές για αυτή την εργασία ακόμα.</div>
    <?php else: ?>

      <div class="tableWrap">
        <table class="dataTable">
          <thead>
            <tr>
              <th>Submission ID</th>
              <th>Student ID</th>
              <th>Υποβολή</th>
              <th>Αρχείο</th>
              <th>Submitted</th>
              <th>Βαθμός</th>
              <th>Ενέργεια</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($submissions as $s): ?>
            <tr>
              <td><?php echo (int)$s["submission_id"]; ?></td>
              <td><?php echo (int)$s["student_id"]; ?></td>
              <td class="textCell">
                <?php
                  $txt = trim($s["submission_text"] ?? "");
                  echo htmlspecialchars(mb_strimwidth($txt, 0, 90, "..."));
                ?>
              </td>
              <td>
                <?php if (!empty($s["file_path"])): ?>
                  <a class="fileLink" href="<?php echo htmlspecialchars($s["file_path"]); ?>" target="_blank">Άνοιγμα</a>
                <?php else: ?>
                  -
                <?php endif; ?>
              </td>
              <td><?php echo htmlspecialchars($s["submitted_at"]); ?></td>
              <td>
                <?php if ($s["grade_value"] !== null): ?>
                  <span class="badge badgeGreen"><?php echo htmlspecialchars($s["grade_value"]); ?></span>
                <?php else: ?>
                  <span class="badge badgeGray">Χωρίς</span>
                <?php endif; ?>
              </td>
              <td>
                <a class="actionBtn" href="teacher_grades.php?submission_id=<?php echo (int)$s["submission_id"]; ?>">
                  Βαθμολόγηση
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    <?php endif; ?>
  <?php endif; ?>

</div>

</body>
</html>
