<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <title>University Portal</title>
   
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css">
    <link rel="stylesheet" href="css/index.css"> 

  
</head>
<body>

<header>
    University Portal – Καλώς ήρθατε
</header>

<div class="container">

    <h2>Σχετικά με το Campus</h2>
    <p>
        Το Πανεπιστήμιό μας προσφέρει ένα σύγχρονο και φιλικό περιβάλλον μάθησης,
        με άρτια εξοπλισμένες αίθουσες, εργαστήρια, βιβλιοθήκη και χώρους μελέτης.
    </p>

    <div class="images">
        <img src="pictures/campus1.jpg" alt="Campus Image 1">
        <img src="pictures/campus2.jpg" alt="Campus Image 2">
    </div>

    <h3>Τοποθεσία Campus</h3>
    <div id="map"></div>

    <div class="buttons">
        <a href="login.php">Σύνδεση</a>
        <a href="register.php">Εγγραφή</a>
    </div>

</div>


<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

<script>
    
    const map = L.map('map').setView([40.6401, 22.9444], 13); 

    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19
    }).addTo(map);

   
    L.marker([40.6401, 22.9444]).addTo(map)
        .bindPopup("Πανεπιστήμιο – Κύριο Campus")
        .openPopup();
</script>

</body>
</html>
