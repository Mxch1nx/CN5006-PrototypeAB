<?php
require_once "auth.php";
requireStudent();
require_once "db.php";

$student_id = $_SESSION["student_id"] ?? 0;

$sql = "
  SELECT 
    g.grade_value,
    g.feedback,
    g.graded_at,
    a.title,
    a.description,
    a.due_date
  FROM grades g
  JOIN submissions s ON g.submission_id = s.id
  JOIN assignments a ON s.assignment_id = a.id
  WHERE s.student_id = ?
  ORDER BY g.graded_at DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <title>Student Grades</title>
  <link rel="stylesheet" href="css/student_home.css">
</head>
<body>

<div class="header">Student Dashboard</div>

<div class="box">
  <h2>Οι Βαθμοί μου</h2>

  <?php if ($result->num_rows === 0): ?>
    <p>Δεν υπάρχουν βαθμολογίες ακόμα.</p>
  <?php else: ?>
    <div class="menu" style="gap:10px;">
      <?php while($row = $result->fetch_assoc()): ?>
        <div class="menuItem" style="display:block; text-align:left;">
          <strong><?php echo htmlspecialchars($row["title"]); ?></strong><br>
          <span><?php echo htmlspecialchars($row["description"]); ?></span><br><br>

          <small>
            Due: <?php echo htmlspecialchars($row["due_date"]); ?><br>
            Grade: <strong><?php echo htmlspecialchars($row["grade_value"]); ?></strong><br>
            Feedback: <?php echo htmlspecialchars($row["feedback"]); ?>
          </small>
        </div>
      <?php endwhile; ?>
    </div>
  <?php endif; ?>

  <br>
  <a class="logout" href="dashboard.php">⬅ Πίσω</a>
</div>

</body>
</html>
