-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Εξυπηρετητής: 127.0.0.1
-- Χρόνος δημιουργίας: 13 Ιαν 2026 στις 18:20:31
-- Έκδοση διακομιστή: 10.4.32-MariaDB
-- Έκδοση PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `university_system`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `assignments`
--

CREATE TABLE `assignments` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `due_date` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `assignments`
--

INSERT INTO `assignments` (`id`, `course_id`, `title`, `description`, `due_date`, `created_at`) VALUES
(1, 1, 'Assignment 1 - HTML Basics\r\n', 'Create a simple HTML page with basic structure.\r\n', '2026-01-20 00:00:00', '2026-01-11 18:00:00'),
(2, 7, 'sss', 'ssss', '2026-01-12 20:17:00', '2026-01-12 20:17:10'),
(3, 8, 'ergasia testestest', 'ffffffffffffff', '2026-01-13 23:59:59', '2026-01-13 17:26:56');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `courses`
--

INSERT INTO `courses` (`id`, `title`, `description`, `teacher_id`, `created_at`) VALUES
(1, 'Web Development\r\n', 'HTML, CSS, PHP basics\r\n', 3, '2026-01-11 16:39:02'),
(5, 'COURSE 22222', 'testestetsestetst', 9, '2026-01-12 20:41:42'),
(7, 'TETEETETE', '6868686866', 9, '2026-01-12 20:42:14'),
(8, 'kainourgio', '5555', 9, '2026-01-13 17:16:36');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `grades`
--

CREATE TABLE `grades` (
  `id` int(11) NOT NULL,
  `submission_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `grade_value` decimal(5,2) NOT NULL,
  `feedback` text NOT NULL,
  `graded_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `grades`
--

INSERT INTO `grades` (`id`, `submission_id`, `teacher_id`, `grade_value`, `feedback`, `graded_at`) VALUES
(1, 1, 9, 10.00, 'athlio', '2026-01-12 20:22:26'),
(2, 2, 9, 999.99, 'kako', '2026-01-12 20:26:01');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `submissions`
--

CREATE TABLE `submissions` (
  `id` int(11) NOT NULL,
  `assignment_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `submission_text` text NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `submitted_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `submissions`
--

INSERT INTO `submissions` (`id`, `assignment_id`, `student_id`, `submission_text`, `file_path`, `submitted_at`) VALUES
(1, 2, 6, 'testestest', '', '2026-01-12 20:19:31'),
(2, 1, 6, '522222222222222', '', '2026-01-12 20:25:34');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('student','teacher') NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Άδειασμα δεδομένων του πίνακα `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `role`, `created_at`) VALUES
(1, '111', '111@gmail.com', '$2y$10$xSsQX9/yFUsAbpu5O1bDReYCNA7O5ILew1GJcCYuSw7gVMVn9Waum', 'student', '2025-12-05 20:29:29'),
(2, '44444', '4444@gmail.com', '$2y$10$7mVUx3QUp4b4J4BE8GHAPebsVIdaVtRDUdxwtQ.gQr6cl9Q5xuKHa', 'student', '2025-12-05 20:53:30'),
(3, 'kathigiths2', 'kathigiths@gmail.com', '$2y$10$kGFBX7ZHmpKT5wucCQHSxO5VcJSk34nar9elHcTqQYPH5inV51o5O', 'teacher', '2025-12-05 21:01:24'),
(4, 'kathigiths2', 'teach@gmail.com', '$2y$10$ipvr0nZn2kUVQ3CBtj1G3ugkSui3uRfeBuUD3wC5Bbix4s6cHT3L.', 'teacher', '2025-12-05 21:06:34'),
(5, 'mathiths', 'stu@gmail.com', '$2y$10$V9FSGKLKE8wfz5gBi1rssegPz9qUz9/59A2O4NPOdtW6Ux36XlJXa', 'student', '2025-12-05 21:29:31'),
(6, 'bill67', 'bill676@gmail.com', '$2y$10$RZ9GyIU6LYSGAF.NFR8oEeq0i.50iQZyo6Tb3gzTD.ywQVPzkCuky', 'student', '2026-01-11 17:05:08'),
(7, 'teach67', 'teach67@gmail.com', '$2y$10$gyT6smbcaHGq0RNoWG9aquqD7a1TbIe2CxpZCaQGjG9B9xV5DiSBq', 'teacher', '2026-01-11 19:04:14'),
(8, 'teach67', 'teach67@gmail.com', '$2y$10$oW8U3yfDEAZtZNZJEkSnqu2BxONhqx3WIV4TbVaGTb9JAxmNglGtq', 'teacher', '2026-01-11 19:04:24'),
(9, 'teach67', 't67@gmail.com', '$2y$10$8NYDLaWe1qC5yqkDJDQeueKrdH1p2pBYd42xG..k1h3vY0z/cOqvG', 'teacher', '2026-01-11 19:06:06');

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`);

--
-- Ευρετήρια για πίνακα `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Ευρετήρια για πίνακα `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`);

--
-- Ευρετήρια για πίνακα `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`id`);

--
-- Ευρετήρια για πίνακα `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT για πίνακα `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT για πίνακα `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT για πίνακα `submissions`
--
ALTER TABLE `submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT για πίνακα `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
